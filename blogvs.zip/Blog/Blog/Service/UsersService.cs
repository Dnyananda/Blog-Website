﻿using Blogs.Data;
using Blogs.Exceptions;
using Blogs.Models;
using Blogs.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Blogs.Service
{
    public class UsersService:IUsersService
    {
        private readonly IUsersRepository _repo;
        public UsersService(IUsersRepository repo)
        {
            _repo = repo;
        }
        public async Task<List<User>> GetUsers()
        {
            return await _repo.GetUsers();
        }
        public async Task<User> GetUserById(int id)
        {
            if (await _repo.GetUserById(id) == null)
            {
                throw new UsersNotFoundException($"User with User id {id} does not exists");
            }
            return await _repo.GetUserById(id);
        }
        public async Task<User> PostUser(User user)
        {
            if(await _repo.UserExists(user)!=null)
            {
                throw new UsersAlreadyExsistException($"User with User email {user.Email} is already exists");
            }
            return await _repo.PostUser(user);
        }
        public async Task<User> PutUser(int id, User user)
        {

            if (await _repo.GetUserById(id) == null)
            {
                throw new UsersNotFoundException($"User with User id {id} does not exists");
            }
            return await _repo.PutUser(id, user);
        }
        public async Task<User> DeleteUser(int id)
        {
            if (await _repo.GetUserById(id) == null)
            {
                throw new UsersNotFoundException($"User with User id {id} does not exists");
            }
            return await _repo.DeleteUser(id);
        }
        public async Task<string> Login(string email, string password)
        {
            return await _repo.Login(email, password);
        }
    }
}
