﻿namespace Blogs.Exceptions
{
    public class UsersAlreadyExsistException : ApplicationException
    {
        public UsersAlreadyExsistException() { }

        public UsersAlreadyExsistException(string msg) : base(msg) { }
    }
}
