﻿namespace Blogs.Exceptions
{
    public class UsersNotFoundException : ApplicationException
    {
        public UsersNotFoundException() { }

        public UsersNotFoundException(string msg) : base(msg) { }
    }
}
