﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Blogs.Models
{
    public class Blog
    {
        [Key]
        [Required]
        public int Idblog { get; set; }
        [Required(ErrorMessage = "Title is required")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Details is required")]
        public string Details { get;set; }
        [Required]
        public DateTime CreatedDate { get; set; }
        [Required]
        public int UserId { get; set; }
        /*[ForeignKey("UserId")]
        public User User { get; set; }*/
    }
}




