﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Blogs.Data;
using Blogs.Models;
using Microsoft.AspNetCore.Authorization;
using Blogs.Repository;
using Blogs.Aspects;
using Blogs.Service;
using Microsoft.AspNetCore.Cors;

namespace Blogs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    [EnableCors("policy")]
    public class BlogsController : ControllerBase
    {
        private readonly BlogContext _context;
        private readonly IBlogsService _serv;
        public BlogsController(BlogContext context,IBlogsService serv)
        {
            _context = context;
            _serv = serv;
        }
        [HttpGet]  
        public async Task<ActionResult<IEnumerable<Blogs.Models.Blog>>> GetBlogs()
        {
            return await _serv.GetBlogs();
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<Blogs.Models.Blog>> GetBlog(int id)
        {
            return await _serv.GetBlogById(id);
        }
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> PutBlog(int id, Blogs.Models.Blog blog)
        {
            if (id != blog.Idblog)
            {
                return BadRequest();
            }
            await _serv.PutBlog(id, blog);
            return NoContent();
        }
        [HttpPost]
        public async Task<ActionResult<Blogs.Models.Blog>> PostBlog(Blogs.Models.Blog blog)
        {
            blog.UserId = GetidFromToken();
            var result = await _serv.PostBlog(blog);
            return CreatedAtAction("GetBlog", new { id = result.Idblog }, result);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBlog(int id)
        {
            return Ok(await _serv.DeleteBlog(id));
        }
        [HttpGet]
        [Route("getmypost")]
        public async Task<IActionResult> getMypost()
        {
            int myid = GetidFromToken();
            return Ok(await _serv.getMypost(myid));
        }
        [HttpGet("/bytitle")]
        public async Task<IActionResult> Search([FromQuery] string? FilterQuery = null)
        {
            var result = await _serv.Search(FilterQuery);
            return Ok(result);
        }
        private int GetidFromToken()
        {
            var id = HttpContext.User.FindFirst("UserId").Value;
            return int.Parse(id);
        }
    }
}
