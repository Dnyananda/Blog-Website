﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Blogs.Data;
using Blogs.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Blogs.Repository;
using Blogs.Service;
using Blogs.Migrations;
using Blogs.Aspects;
using Microsoft.AspNetCore.Cors;

namespace Blogs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    [EnableCors("policy")]
    public class UsersController : ControllerBase
    {
        private readonly BlogContext _context;
        private readonly IUsersService _serv;
        public UsersController(BlogContext context,IUsersService serv)
        {
            _context = context;
            _serv = serv;
        }
        [HttpGet]
        [Authorize]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
           return await _serv.GetUsers();
        }
        [HttpGet]
        [Authorize]
        [Route("user")]
        public async Task<ActionResult<User>> GetUser()
        {
            int id = GetidFromToken();
            return await _serv.GetUserById(id);
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUser(int id, User user)
        {
            if (id != user.UserId)
            {
                return BadRequest();
            }
            await _serv.PutUser(id, user);
            return NoContent();
        }
        [HttpPost]
        public async Task<ActionResult<User>> PostUser(User user)
        {
            var result = await _serv.PostUser(user);
            return CreatedAtAction("GetUser", new { id = result.UserId }, result);       
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            return Ok(await _serv.DeleteUser(id));
        }
        [HttpPost("login/{email}/{password}")]
        public async Task<string> Login(string email, string password)
        {
            return await _serv.Login(email, password);    
        }
        private int GetidFromToken()
        {
            var id = HttpContext.User.FindFirst("UserId").Value;
            return int.Parse(id);
        }
    }
}
